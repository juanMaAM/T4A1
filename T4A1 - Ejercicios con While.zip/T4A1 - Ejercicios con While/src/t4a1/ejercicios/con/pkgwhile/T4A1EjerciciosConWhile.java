package t4a1.ejercicios.con.pkgwhile;
import java.awt.BorderLayout;
import java.util.Scanner;
public class T4A1EjerciciosConWhile {

    public static void main(String[] args) {
        
        // ejercicio1();
        // ejercicio2();
        // rcicio3();
        // rcicio4();
        
    }
    public static void ejercicio1(){
        // 1. Escribir un programa que solicite un n�mero positivo
        // y nos muestre desde 1 hasta el valor ingresado de uno en uno.
        // Ejemplo: Si ingresamos 30 se debe mostrar en pantalla los n�meros del 1 al 30.
        
        Scanner scanner = new Scanner(System.in);
        
        int N = 0;
        
        System.out.println("Ingresa el limite");
        int L = scanner.nextInt();
        
        while(N < L){
            N++;
            System.out.println(N);
        }
      
    }
    /* 2. Una maquiladora confecciona pantalones y recibe
    un lote de N piezas para un cliente X. Crear
    un programa en Java que solicite la cantidad de piezas
    a confeccionar y luego se ingrese las respectivas tallas
    que pueden ser S, M, L y XL. Luego, imprimir en pantalla
    la cantidad de piezas confeccionadas por talla. 
    */
    
    public static void ejercicio2(){
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Piezas");
        int npiezas = scanner.nextInt();
        int n = 0, tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;
        
        
        while (n < npiezas){
            n++;
            System.out.print("\nTalla");
            String talla = scanner.next();
            
            if (talla.equals("S") || talla.equals("s")){
                tallaS++;
            }else if(talla.equals("M") || talla.equals("m")){
                tallaM++;
            }else if(talla.equals("L") || talla.equals("l")){
                tallaL++;
            }else if(talla.equals("XL") || talla.equals("xl")){
                tallaXL++;
            }else{
            }
            
            System.out.print("Cantidades por talla: \n"
                    + "Chica (S)\t\t" + tallaS + "\n"
                    + "Mediana (M)\t\t" + tallaM + "\n"
                    + "Grande (G)\t\t" + tallaL + "\n"
                    + "Extragrande (XL)\t\t" + tallaXL + "\n");
        }
    }
    /*
    3. Escribir un programa en Java que solicite N calificaciones
    de estudiantes en una escala del 0 al 100 y que informe cu�ntos
    tienen calificaci�n mayor o igual a 70 y cu�ntos tienen una calificaci�n menor. 
    */
    public static void ejercicio3(){
        Scanner scanner = new Scanner(System.in);
        
        
        
        
    }
    /*
    4. Escribir un programa en Java que imprima los m�ltiplos del n�mero que
    indique el usuario hasta la cantidad deseada. El usuario debe indicar el
    m�ltiplo y el n�mero hasta el cual quiere llegar. Ejemplo:

	M�ltiplo: 3
	Quiero llegar hasta: 20
	Resultado: 3, 6, 9, 12, 15, 18
    */
    public static void ejercicio4(){
        Scanner scanner = new Scanner(System.in);
        
    }
    
}


